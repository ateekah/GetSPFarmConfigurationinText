﻿#add-pssnapin "microsoft.sharepoint.powershell"
#Log in with the Farm account
#Run in SharePoint Management shell as administrator

psconfig.exe -cmd configdb -create -server sqlaliasnamew -database SPSUBTEST_Config_db -user domain\farmaccount -password Yourpassword -admincontentdatabase SPSUBTEST_CentralAdminContent -passphrase Yourpassword -localserverrole custom