Add-PSSnapin Microsoft.SharePoint.Powershell;
Install-SPHelpCollection -All;
Initialize-SPResourceSecurity;
Install-SPService;
Install-SPFeature -AllExistingFeatures;