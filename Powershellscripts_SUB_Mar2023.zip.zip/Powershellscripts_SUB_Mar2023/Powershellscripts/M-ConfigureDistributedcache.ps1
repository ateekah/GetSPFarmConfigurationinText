Add-PSSnapin "microsoft.sharepoint.powershell"
# For Sharepoint Subscription version, use these commands
# Run as adminsitator in Sharepoint management shell

Use-SPCacheCluster
Get-SPCacheHostConfig -HostName $Env:ComputerName



#Check Memory allocation- for sp2013
Use-CacheCluster
Get-AFCacheHostConfiguration -ComputerName $Env:ComputerName -CachePort "22233"



#Update Distributed Cache
Update-SPDistributedCacheSize -CacheSizeInMB <CacheSize>

____________________________________________________________________________________________
#Stop Distributed Cache
$instanceName ="SPDistributedCacheService Name=AppFabricCachingService"
$serviceInstance = Get-SPServiceInstance | ? {($_.service.tostring()) -eq $instanceName -and ($_.server.name) -eq $env:computername}
$serviceInstance.Unprovision()

#Start Dist Cache
$instanceName ="SPDistributedCacheService Name=AppFabricCachingService"
$serviceInstance = Get-SPServiceInstance | ? {($_.service.tostring()) -eq $instanceName -and ($_.server.name) -eq $env:computername}
$serviceInstance.Provision()


#Remove Distributed Cache
Remove-SPDistributedCacheServiceInstance




