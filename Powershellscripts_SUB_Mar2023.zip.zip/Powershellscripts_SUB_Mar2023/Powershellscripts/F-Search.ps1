﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue

$AppSvr = Read-Host "Specify Search Server name. Example: SPAPP01";
$saAppPoolName = Read-Host "Specify Application Pool Name. Example: Search_AppPool";
$appPoolUserName = Read-Host "Specify Search Service Account Name. Example: Domain\SVCSPPRDSVC";
$SSAName = "Search Service";
$DatabaseName = Read-Host "Specify a farm name. The farm name is used to provide consistency with database naming.  The farm name will be in the beginning of all SharePoint database names.  For example, the farm name SP13PRD will lead to the following database names: SP13PRD_WSS_Content and SP13PRD_ConfigDB. Enter the FARM name with no quotes, spaces or underscores. Example: SP13PRD";
$SSIAppSvr = get-SPServiceInstance -server $AppSvr | ?{$_.TypeName -eq "SharePoint Server Search"};
$IndexLocation = Read-Host "Specify Index location. Example: E:\SP2013\SearchIndex";


Write-Host -ForegroundColor Cyan "Checking if Application Pool exists..."

$saAppPool = Get-SPServiceApplicationPool -Identity $saAppPoolName -EA 0
if($saAppPool -eq $null)
{
  Write-Host -ForegroundColor Cyan "Creating Service Application Pool..."
  $appPoolAccount = Get-SPManagedAccount -Identity $appPoolUserName -EA 0
  if($appPoolAccount -eq $null)
  {
      Write-Host -ForegroundColor Cyan "Please supply the password for the Service Account..."
      $appPoolCred = Get-Credential $appPoolUserName
      $appPoolAccount = New-SPManagedAccount -Credential $appPoolCred -EA 0
  }
  $appPoolAccount = Get-SPManagedAccount -Identity $appPoolUserName -EA 0

  if($appPoolAccount -eq $null)
  {
    Write-Host -ForegroundColor Red "Cannot create or find the managed account $appPoolUserName, please ensure the account exists."
    Exit -1
  }

  New-SPServiceApplicationPool -Name $saAppPoolName -Account $appPoolAccount -EA 0 > $null
  
}


Write-host -ForegroundColor Cyan "Starting Search Service on $AppSvr..."

Start-SPEnterpriseSearchServiceInstance -Identity $SSIAppSvr


Write-host -ForegroundColor Cyan "Creating the $SSAName..."

$SearchApp = New-SPEnterpriseSearchServiceApplication -Name $SSAName -applicationpool $SAAppPoolName -databasename $DatabaseName"_SearchDB"


Write-host -ForegroundColor Cyan "Creating search service application proxy..."

$SSAProxy = new-spenterprisesearchserviceapplicationproxy -name $SSAName"ApplicationProxy" -SearchApplication $SearchApp


Write-host -ForegroundColor Cyan "Cloning Search Topology..."

$SearchTopology = $SearchApp.ActiveTopology.Clone()


Write-host -ForegroundColor Cyan "Provisioning Search Admin Component..."

New-SPEnterpriseSearchAdminComponent -SearchServiceInstance $SSIAppSvr -SearchTopology $SearchTopology

Write-host -ForegroundColor Cyan "Creating New Search Content Processing Component..."

New-SPEnterpriseSearchContentProcessingComponent -SearchServiceInstance $SSIAppSvr -SearchTopology $SearchTopology

Write-host -ForegroundColor Cyan "Creating New Search Analytics Processing
Component..."

New-SPEnterpriseSearchAnalyticsProcessingComponent -SearchServiceInstance $SSIAppSvr -SearchTopology $SearchTopology

Write-host -ForegroundColor Cyan "Creating New Search Crawl Component..."

New-SPEnterpriseSearchCrawlComponent -SearchServiceInstance $SSIAppSvr -SearchTopology $SearchTopology

Write-host -ForegroundColor Cyan "Creating New Search Index Component..."

New-SPEnterpriseSearchIndexComponent -SearchServiceInstance $SSIAppSvr -SearchTopology $SearchTopology -RootDirectory $IndexLocation

Write-host -ForegroundColor Cyan "Creating New Query Processing Component..."

New-SPEnterpriseSearchQueryProcessingComponent -SearchServiceInstance $SSIAppSvr -SearchTopology $SearchTopology

Write-host -ForegroundColor Cyan "Activating Topology..."

$SearchTopology.Activate()

Write-host -ForegroundColor Green "The $SSAName is now ready"

