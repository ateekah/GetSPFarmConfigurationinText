﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue

# Settings will prompt for values... 

$WebAppName = read-host "Specify web app description. Example: SharePoint"
$WebAppHostHeader = read-host "Specify host header. Example: SharePoint"
$WebAppPort = read-host "Specify port. Example: 80"
$WebAppAppPool = read-host "Specify application pool name. Example: SharePoint_AppPool"
$WebAppAppPoolAccount = read-host "Specify application pool identity. Example: DOMAIN\SVCSPPRDWEB"
$WebAppDatabaseName = read-host "Specify content database name. Example: SP13PRD_Content_SharePoint"
$WebAppDatabaseServer = read-host "Specify SQL Server instance name or SQL Alias name"
$AuthPro = New-SPAuthenticationProvider

# Remove mark for enabling Windows KERBEROS with claims. Default setting is to enable Windows NTLM with claims.
# $AuthPro.DisableKerberos = $false

Write-Host -ForegroundColor Cyan "Creating Web Application..."

New-SPWebApplication -Name $WebAppName -authenticationprovider $AuthPro -Port $WebAppPort -HostHeader $WebAppHostHeader -URL ("http://" + $WebAppHostHeader) -ApplicationPool $WebAppAppPool -ApplicationPoolAccount (Get-SPManagedAccount $WebAppAppPoolAccount) -DatabaseName $WebAppDatabaseName -DatabaseServer $WebAppDatabaseServer

# Database is dropped because usually there is a content database migration. Add a mark # by the Remove-SPContentDatabase line to retain the database created in this script. 
 
#Remove-SPContentDatabase -Identity $WebAppDatabaseName

Write-Host -ForegroundColor Green "Web Application Created."


