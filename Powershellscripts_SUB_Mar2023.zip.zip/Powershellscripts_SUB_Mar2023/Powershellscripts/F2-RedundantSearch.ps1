Create Search Service Application and Topology 
(Redundant Server Design ONLY, SKIP if using One Search server)
Logon to App server and run the following PowerShell command from the SharePoint 2016 Management Shell

CreateSearch-RedundantDesign.ps1

Note 1:  Create the E:\SP2016\SearchIndex folder location before attempting to run the script.

Note 2:  Modify the highlighted text in the script below before running it.


Add-PSSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue

$SearchA = "SERVERNAME1"
$SearchB = "SERVERNAME2"

# Start Services search service instance...

Write-host -ForegroundColor Cyan "Starting Search Service instances on $SearchA ...."

Start-SPEnterpriseSearchServiceInstance $SearchA -ErrorAction SilentlyContinue
Start-SPEnterpriseSearchQueryAndSiteSettingsServiceInstance $SearchA -ErrorAction SilentlyContinue

Write-host -ForegroundColor Cyan "Starting Search Service instances on $($searchB)...."

Start-SPEnterpriseSearchServiceInstance $SearchB -ErrorAction SilentlyContinue
Start-SPEnterpriseSearchQueryAndSiteSettingsServiceInstance $SearchB -ErrorAction SilentlyContinue 

$hostA = Get-SPEnterpriseSearchServiceInstance -Identity "SERVERNAME1"
$hostB = Get-SPEnterpriseSearchServiceInstance -Identity "SERVERNAME2"

$RootDirectory = "F:\SP2019\SearchIndex";
$saAppPoolName = "Search_AppPool";
$appPoolUserName = "Domain\SVCSPPRDSVC";
$SearchServerName = "SERVERNAME1";
$SearchServiceName = "Search Service";
$SearchServiceProxyName = "Search Service Proxy";
$DatabaseName = "SP13PRD_SearchDB";

Write-Host -ForegroundColor Cyan "Checking if Application Pool exists..."

$saAppPool = Get-SPServiceApplicationPool -Identity $saAppPoolName -EA 0
if($saAppPool -eq $null)
{
  Write-Host -ForegroundColor Cyan "Creating Service Application Pool..."
  $appPoolAccount = Get-SPManagedAccount -Identity $appPoolUserName -EA 0
  if($appPoolAccount -eq $null)
  {
      Write-Host -ForegroundColor Cyan "Please supply the password for the Service Account..."
      $appPoolCred = Get-Credential $appPoolUserName
      $appPoolAccount = New-SPManagedAccount -Credential $appPoolCred -EA 0
  }
  $appPoolAccount = Get-SPManagedAccount -Identity $appPoolUserName -EA 0

  if($appPoolAccount -eq $null)
  {
    Write-Host -ForegroundColor Red "Cannot create or find the managed account $appPoolUserName, please ensure the account exists."
    Exit -1
  }

  New-SPServiceApplicationPool -Name $saAppPoolName -Account $appPoolAccount -EA 0 > $null
  
}


Write-Host -ForegroundColor Cyan "Creating Search Service Application..."

$ServiceApplication = New-SPEnterpriseSearchServiceApplication -Name $SearchServiceName -ApplicationPool $saAppPoolName -DatabaseName $DatabaseName

Write-Host -ForegroundColor Cyan "Creating Search Service Application Proxy..."

New-SPEnterpriseSearchServiceApplicationProxy -Name $SearchServiceProxyName -SearchApplication $ServiceApplication

Write-Host -ForegroundColor Cyan "Modifying Search Topology..."

$SSA = Get-SPEnterpriseSearchServiceApplication
$newTopology = New-SPEnterpriseSearchTopology -SearchApplication $SSA

New-SPEnterpriseSearchAdminComponent -SearchTopology $newTopology -SearchServiceInstance $hostA
New-SPEnterpriseSearchAdminComponent -SearchTopology $newTopology -SearchServiceInstance $hostB
New-SPEnterpriseSearchCrawlComponent -SearchTopology $newTopology -SearchServiceInstance $hostA
New-SPEnterpriseSearchCrawlComponent -SearchTopology $newTopology -SearchServiceInstance $hostB
New-SPEnterpriseSearchContentProcessingComponent -SearchTopology $newTopology -SearchServiceInstance $hostA
New-SPEnterpriseSearchContentProcessingComponent -SearchTopology $newTopology -SearchServiceInstance $hostB
New-SPEnterpriseSearchAnalyticsProcessingComponent -SearchTopology $newTopology -SearchServiceInstance $hostA
New-SPEnterpriseSearchAnalyticsProcessingComponent -SearchTopology $newTopology -SearchServiceInstance $hostB
New-SPEnterpriseSearchQueryProcessingComponent -SearchTopology $newTopology -SearchServiceInstance $hostA
New-SPEnterpriseSearchQueryProcessingComponent -SearchTopology $newTopology -SearchServiceInstance $hostB
New-SPEnterpriseSearchIndexComponent -SearchTopology $newTopology -SearchServiceInstance $hostA -IndexPartition 0 –RootDirectory $RootDirectory
New-SPEnterpriseSearchIndexComponent -SearchTopology $newTopology -SearchServiceInstance $hostB -IndexPartition 0 –RootDirectory $RootDirectory
Set-SPEnterpriseSearchTopology -Identity $newTopology

Get-SPEnterpriseSearchTopology -SearchApplication "Search Service"
Get-SPEnterpriseSearchStatus -SearchApplication "Search Service" –Text

Write-Host -ForegroundColor Green "Search Service Application and Topology Completed."


Note: Set the CRAWL Account in the Search Service Application.

Note: Add the SPS3 protocol "SPS3://mysites" (replace mysites with the URL of your MySite host protocol to the "Local SharePoint Sites" Content Source in order to populate people search results.



