﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue

# Settings will prompt for values... 

$WebAppName = read-host "Specify MySite description. Example: MySites"
$WebAppHostHeader = read-host "Specify host header. Example: MySites"
$WebAppPort = read-host "Specify port. Example: 80"
$WebAppAppPool = read-host "Specify application pool name. Example: MySites_AppPool"
$WebAppAppPoolAccount = read-host "Specify application pool identity. Example: DOMAIN\SVCSPPRDWEB"
$WebAppDatabaseName = read-host "Specify content database name. Example: SP13PRD_Content_MySites"
$WebAppDatabaseServer = read-host "Specify SQL Server instance name or SQL Alias name"
$SiteCollectionName = "My"
$SiteCollectionURL = "http://$($WebAppHostHeader):$($WebAppPort)"
$SiteCollectionTemplate = "SPSMSITEHOST#0"
$SiteCollectionLanguage = 1033
$SiteCollectionOwner = read-host "Enter site owner.  Example: DOMAIN\USERNAME"
$AuthPro = New-SPAuthenticationProvider

# Remove mark for setting Kerberos with claims...
# $AuthPro.DisableKerberos = $false

Write-Host -ForegroundColor Cyan "Creating MySite Web Application..."

New-SPWebApplication -Name $WebAppName -authenticationprovider $AuthPro -Port $WebAppPort -HostHeader $WebAppHostHeader -URL ("http://" + $WebAppHostHeader) -ApplicationPool $WebAppAppPool -ApplicationPoolAccount (Get-SPManagedAccount $WebAppAppPoolAccount) -DatabaseName $WebAppDatabaseName -DatabaseServer $WebAppDatabaseServer

Write-Host -ForegroundColor Cyan "Creating MySite Host Site Collection..."

New-SPSite -URL $SiteCollectionURL -OwnerAlias $SiteCollectionOwner -Language $SiteCollectionLanguage -Template $SiteCollectionTemplate -Name $SiteCollectionName 

Write-Host -ForegroundColor Green "MySite Web Application Created."
