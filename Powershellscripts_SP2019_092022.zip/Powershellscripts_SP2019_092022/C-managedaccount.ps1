﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue

# Settings will prompt for values... 

$saAppPoolName = read-host "Specify application pool name. Example: Web_AppPool"
$appPoolUserName = read-host "Specify application pool identity. Example: DOMAIN\SVCSPPRDWEB"
 
$saAppPool = Get-SPServiceApplicationPool -Identity $saAppPoolName -EA 0
if($saAppPool -eq $null)
{
  Write-Host -ForegroundColor Cyan "Creating Web Application Pool..."
 
  $appPoolAccount = Get-SPManagedAccount -Identity $appPoolUserName -EA 0
  if($appPoolAccount -eq $null)
  {
      Write-Host "Supply the password for the Service Account..."
      $appPoolCred = Get-Credential $appPoolUserName
      $appPoolAccount = New-SPManagedAccount -Credential $appPoolCred -EA 0
  }
  $appPoolAccount = Get-SPManagedAccount -Identity $appPoolUserName -EA 0
  if($appPoolAccount -eq $null)
  {

Write-Host -ForegroundColor Red "Cannot create or find the managed account $appPoolUserName, please ensure the account exists."
    Exit -1
  }
  New-SPServiceApplicationPool -Name $saAppPoolName -Account $appPoolAccount -EA 0 > $null
}

Write-Host -ForegroundColor Green "Managed Account and Web Application Pool Created."


