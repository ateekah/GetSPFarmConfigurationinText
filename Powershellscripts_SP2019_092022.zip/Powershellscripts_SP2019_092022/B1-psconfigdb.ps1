﻿add-pssnapin "microsoft.sharepoint.powershell"


psconfig.exe -cmd configdb -create -server sqlaliasnamew -database SP2019_Config_db -user domain\farmaccount -password Yourpassword -admincontentdatabase SP2019_CentralAdminContent -passphrase Yourpassword -localserverrole custom