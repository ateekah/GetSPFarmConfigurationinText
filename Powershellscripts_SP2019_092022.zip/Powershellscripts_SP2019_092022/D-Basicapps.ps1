﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue

# run get-spserviceapplicationpool to find out names of current serviceapplication pool

# Settings will prompt for values...

$databaseServerName = read-host "Specify SQL Server instance name or SQL Alias name";
$FarmName = read-host "Specify a farm name. The farm name is used to provide consistency with database naming.  The farm name will be in the beginning of all SharePoint database names.  For example, the farm name SP13PRD will lead to the following database names: SP13PRD_WSS_Content and SP13PRD_ConfigDB. Enter the FARM name with no quotes, spaces or underscores. Example: SP13PRD";
$saAppPoolName = read-host "Specify application pool name. Example: Services_AppPool"; 
$appPoolUserName = read-host "Specify application pool identity. Example: DOMAIN\SVCSPPRDSVC";
$UsageLogLocation = read-host "Specify usage log location. Example: E:\SP2013\Logs\Usage";
$SetDiagnosticLogs = read-host "Specify diagnostic log location. Example: E:\SP2013\Logs\Diagnostic";
 
# Database Names...
 
$BusinessDataCatalogDBName = $FarmName+"_BusinessDataCatalogDB";
$MetadataDBName = $FarmName+"_MetadataDB";
$UsageDBName = $FarmName+"_UsageDB";
$StateServiceDBName = $FarmName+"_StateServiceDB";
$WordAutomationDBName = $FarmName+"_WordAutomationDB";
$SecureStoreDBName = $FarmName+"_SecureStoreDB";
 
# Service Application Service Names...
 
$bcsSAName = "Business Data Connectivity Service"
$metadataSAName = "Managed Metadata Service"
$usageSAName = "Usage and Health Data Collection Service"
$stateSAName = "State Service"
$WordAutomationSAName = "Word Automation Service"
$secureStoreSAName = "Secure Store Service"

Write-Host -ForegroundColor Cyan "Checking if Application Pool exists..."

$saAppPool = Get-SPServiceApplicationPool -Identity $saAppPoolName -EA 0
if($saAppPool -eq $null)
{
  Write-Host -ForegroundColor Cyan "Creating Service Application Pool..."
  $appPoolAccount = Get-SPManagedAccount -Identity $appPoolUserName -EA 0
  if($appPoolAccount -eq $null)
  {
      Write-Host -ForegroundColor Cyan "Please supply the password for the Service Account..."
      $appPoolCred = Get-Credential $appPoolUserName
      $appPoolAccount = New-SPManagedAccount -Credential $appPoolCred -EA 0
  }
  $appPoolAccount = Get-SPManagedAccount -Identity $appPoolUserName -EA 0
 
  if($appPoolAccount -eq $null)
  {
    Write-Host -ForegroundColor Red "Cannot create or find the managed account $appPoolUserName, please ensure the account exists."
    Exit -1
  }
 
  New-SPServiceApplicationPool -Name $saAppPoolName -Account $appPoolAccount -EA 0 > $null
  
}
 
Write-Host -ForegroundColor Cyan "Creating Usage Service and Proxy..."

$serviceInstance = Get-SPUsageService
New-SPUsageApplication -Name $usageSAName -DatabaseServer $databaseServerName -DatabaseName $UsageDBName -UsageService $serviceInstance > $null
$serviceInstanceNewUsage = Get-SPUsageService
Set-SPUsageService -Identity $serviceInstanceNewUsage –UsageLogLocation $UsageLogLocation
Set-SPDiagnosticConfig -LogLocation $SetDiagnosticLogs

Write-Host -ForegroundColor Cyan "Creating BCS Service and Proxy..."
New-SPBusinessDataCatalogServiceApplication -Name $bcsSAName -ApplicationPool $saAppPoolName -DatabaseServer $databaseServerName -DatabaseName $BusinessDataCatalogDBName > $null
Get-SPServiceInstance | where-object {$_.TypeName -eq "Business Data Connectivity Service"} | Start-SPServiceInstance > $null

Write-Host -ForegroundColor Cyan "Creating Metadata Service and Proxy..."
New-SPMetadataServiceApplication -Name $metadataSAName -ApplicationPool $saAppPoolName -DatabaseServer $databaseServerName -DatabaseName $MetadataDBName > $null
New-SPMetadataServiceApplicationProxy -Name "$metadataSAName Proxy" -DefaultProxyGroup -ServiceApplication $metadataSAName > $null
Get-SPServiceInstance | where-object {$_.TypeName -eq "Managed Metadata Service"} | Start-SPServiceInstance > $null
 
Write-Host -ForegroundColor Cyan "Creating State Service and Proxy..."
New-SPStateServiceDatabase -Name $StateServiceDBName –DatabaseServer $databaseServerName | New-SPStateServiceApplication -Name $stateSAName | New-SPStateServiceApplicationProxy -Name "$stateSAName Proxy" -DefaultProxyGroup > $null

Write-Host -ForegroundColor Cyan "Creating Word Automation Service and Proxy..."
New-SPWordConversionServiceApplication -Name $WordAutomationSAName -ApplicationPool $saAppPoolName -DatabaseServer $databaseServerName -DatabaseName $WordAutomationDBName -Default > $null
Get-SPServiceInstance | where-object {$_.TypeName -eq "Word Automation Services"} | Start-SPServiceInstance > $null

Write-Host -ForegroundColor Cyan "Creating Secure Store Service and Proxy..."
New-SPSecureStoreServiceapplication -Name $secureStoreSAName -Sharing:$false -DatabaseServer $databaseServerName -DatabaseName $SecureStoreDBName -ApplicationPool $saAppPoolName -auditingEnabled:$true -auditlogmaxsize 30 | New-SPSecureStoreServiceApplicationProxy -name "$secureStoreSAName Proxy" -DefaultProxygroup > $null
Get-SPServiceInstance | where-object {$_.TypeName -eq "Secure Store Service"} | Start-SPServiceInstance > $null

Write-Host -ForegroundColor Green "Service Applications Created."
Get-SPServiceApplication
 
