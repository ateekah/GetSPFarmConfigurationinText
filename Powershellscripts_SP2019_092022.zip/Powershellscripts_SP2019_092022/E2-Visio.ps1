﻿add-pssnapin "Microsoft.sharepoint.powershell"
remove-pssnapin "Microsoft.sharepoint.powershell"
add-pssnapin "Microsoft.sharepoint.powershell"

#Create Visio Application Pool

New-SPServiceApplicationPool -Name "Visio Graphic Service Application Pool"

$VisioAppPool = Get-SPServiceApplicationPool "Visio Graphic Service Application Pool"
 
#Create Visio Service Application

$VisioApp = New-SPVisioServiceApplication -ApplicationPool $VisioAppPool -Name "Visio Graphic Service Application"

Get-SPServiceApplication | Select Name

#Create Visio Application Proxy

$VisioAppProxy = New-SPVisioServiceApplicationProxy -ServiceApplication "Visio Graphic Service Application" -Name "Visio Graphic Service Application Proxy"

Get-SPServiceApplicationProxy | Select Name
 

#start service if it's not running

$visio = Get-SPVisioServiceApplication

$visio.Provision()