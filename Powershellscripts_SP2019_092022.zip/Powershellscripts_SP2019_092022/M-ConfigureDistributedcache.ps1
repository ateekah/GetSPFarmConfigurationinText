Add-PSSnapin "microsoft.sharepoint.powershell"

#Stop Distributed Cache
$instanceName ="SPDistributedCacheService Name=AppFabricCachingService"
$serviceInstance = Get-SPServiceInstance | ? {($_.service.tostring()) -eq $instanceName -and ($_.server.name) -eq $env:computername}
$serviceInstance.Unprovision()

#Start Dist Cache
$instanceName ="SPDistributedCacheService Name=AppFabricCachingService"
$serviceInstance = Get-SPServiceInstance | ? {($_.service.tostring()) -eq $instanceName -and ($_.server.name) -eq $env:computername}
$serviceInstance.Provision()


#Remove Distributed Cache
Remove-SPDistributedCacheServiceInstance


#Update Distributed Cache
Update-SPDistributedCacheSize -CacheSizeInMB CacheSize

#Check Memory allocation
Use-CacheCluster
Get-AFCacheHostConfiguration -ComputerName $Env:ComputerName -CachePort "22233"

