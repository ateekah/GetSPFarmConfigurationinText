﻿Add-PSSnapin "microsoft.sharepoint.powershell"



$wa = Get-SPWebApplication -Identity "http://sp2016site.sp2016.com"
$wa.Properties["portalsuperuseraccount"] = "i:0#.w|sp2016\superuser"
$wa.Properties["portalsuperreaderaccount"] = "i:0#.w|sp2016\superreader"
$wa.Update()



$wa = Get-SPWebApplication -Identity "http://my.sp2016.com/"
$wa.Properties["portalsuperuseraccount"] = "i:0#.w|sp2016\superuser"
$wa.Properties["portalsuperreaderaccount"] = "i:0#.w|sp2016\superreader"
$wa.Update()
